import xbmcaddon

MainBase = 'http://bit.ly/2uzTrMZ'
addon = xbmcaddon.Addon('plugin.video.SchemeStreams')